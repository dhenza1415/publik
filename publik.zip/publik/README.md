# 
termux-setup-storage
cd storage
ls
cd downloads
git clone https://github.com/dhenza1415/publik
cd publik
apt install unzip
unzip publik.zip
cd publik
nano publik.py
note : edit email or paswod
ctrl + x + y + enter
python3 publik.py


all intsalan
apt-get install python3 -y
apt-get install python -y
apt-get install python-pip -y 
apt-get install python3-pip -y
apt-get install python-setuptools -y
apt-get install python3-setuptools -y
pip3 install setuptools
pip3 install tweepy
pip3 install html5lib
pip3 install pafy
pip3 install humanfriendly
pip3 install gtts
pip3 install rsa
pip3 install googletrans
pip3 install pytz
pip3 install wikipedia
pip3 install lxml
pip3 install urllib3
pip3 install timeago
pip3 install wikiapi
pip3 install -U youtube-dl
pip3 install wikiapi
pip3 install beautifulsoup4==4.6.0
pip3 install bs4==0.0.1
pip3 install certifi==2018.4.16
pip3 install chardet==3.0.4
pip3 install click==6.7
pip3 install googletrans==2.3.0
pip3 install gTTS==2.0.1
pip3 install gTTS-token==1.1.1
pip3 install idna==2.7
pip3 install pyasn1==0.4.3
pip3 install pytz==2018.5
pip3 install requests==2.19.1
pip3 install rsa==3.4.2
pip3 install six==1.11.0
pip3 install urllib3==1.23
pip3 install thrift==0.11.0
pip3 install html5
pip3 install keepalive
pip3 install humanize
pip3 install wikiapi
pip3 install timeago
pip3 install akad
pip3 install linepy
pip3 install ffmpeg
pip3 install schematics
pip3 install goslate
pip3 install livejson
pip3 install ffmpy
pip3 install wiki
pip3 install pip --upgrade
cp -v /usr/local/bin/pip3 /usr/bin/pip3
pip3 install setuptools
pip3 install tweepy
pip3 install linepy
pip3 install html5lib
pip3 install pafy
pip3 install youtube_dl
pip3 install humanfriendly
pip3 install pytz
pip3 install wikipedia
pip3 install paramiko
pip3 install naked
pip3 install PyImage
sudo apt-get install -y nodejs && sudo apt-get install yarn curl -sL https://deb.nodesource.com/setup_10.x | sudo bash - && apt install unzip
apt update && apt upgrade -y